<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use App\Models\Contacts;
use Illuminate\Support\Facades\Hash;

class Add extends Controller
{
    //

    public function add()
    {
        if (Auth::check()) {
            return view('add/add');
        }

        return redirect("login")->withSuccess('wa kay access bai');
    }

    public function save(Request $request) {

        if (Auth::check()) {
            $user = Auth::user();
            if ($user) {
                $userId = $user->id;
                $add = new Contacts();
                $add->name = $request['name'];
                $add->contact_owner_id = $userId;
                $add->company = $request['company'];
                $add->phone = $request['phone'];
                $add->email = $request['email'];
                $add->save();
            return redirect('contact');
            } else {
                return redirect()->route('contact')->withSuccess('wa kay access bai');
            }
        }
        return redirect()->route('contact')->withSuccess('wa kay access bai');
    }

    public function edit(Request $request , $id)
    {

        if (Auth::check()) {
            $contact = Contacts::find($id);
            return view('add/edit', compact('contact'));
        }

        return redirect("login")->withSuccess('wa kay access bai');
    }

    public function update(Request $request)
    {

        if (Auth::check()) {
            $contactId = $request->input('contact_id');
            $contact = Contacts::find($contactId);

            if (!$contact) {
                abort(404);
            }
            $contact->name = $request->input('name');
            $contact->company = $request->input('company');
            $contact->phone = $request->input('phone');
            $contact->email = $request->input('email');
            $contact->save();

            return redirect('contact');
        }
        return redirect()->route('contact')->withSuccess('wa kay access bai');
    }

    public function delete($id)
    {

        if (Auth::check()) {
            $delete_contact = Contacts::find($id);
            $delete_contact->delete();
        }
        return redirect()->route('contact')->withSuccess('wa kay access bai');

    }

    public function search(Request $request){
        $user = Auth::user();
        $query = $request->input('query');
        $userId = $user->id;
        $getSearch = Contacts::where('contact_owner_id', $userId)->where('name', 'like', '%' . $query . '%')->get();
        return response()->json($getSearch);
    }

}
