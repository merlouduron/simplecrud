<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Add;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('login', [AuthController::class, 'index'])->name('login');
Route::post('post-login', [AuthController::class, 'postLogin'])->name('login.post');
Route::get('registration', [AuthController::class, 'registration'])->name('register');
Route::post('post-registration', [AuthController::class, 'postRegistration'])->name('register.post');
Route::get('thankyou', [AuthController::class, 'thankyou']);
Route::get('contact', [AuthController::class, 'contact'])->name('contact');
Route::get('logout', [AuthController::class, 'logout'])->name('logout');
Route::get('add', [Add::class, 'add'])->name('add');
Route::post('submit', [Add::class, 'save'])->name('save');
Route::get('edit/{id}', [Add::class, 'edit'])->name('edit');
Route::post('update', [Add::class, 'update'])->name('update');
Route::get('delete/{id}', [Add::class, 'delete'])->name('delete');
Route::get('search', [Add::class, 'search'])->name('search');

