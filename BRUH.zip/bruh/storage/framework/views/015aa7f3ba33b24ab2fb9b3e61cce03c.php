kfn lksajdf
<?php /**PATH C:\Users\User\Desktop\laravel prode\bruh\resources\views/login.blade.php ENDPATH**/ ?>