<?php $__env->startSection('content'); ?>
<div class="main">
<div class="body">
    <div class="taas">
        <h2 class="title">Edit</h2>
    </div>
    <div class="form">
        <form class="uiform" action="/update" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="contact_id" value="<?php echo e($contact->id); ?>">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo e($contact->name); ?>" required>
        <label for="company">Company:</label>
        <input type="text" id="company" name="company" value="<?php echo e($contact->company); ?>" required>
        <label for="phone">Phone:</label>
        <input type="number" id="phone" name="phone" value="<?php echo e($contact->phone); ?>" required>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo e($contact->email); ?>" required>
        <input class="submit" type="submit" value="Submit">
    </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\laravel prode\bruh\resources\views/add/edit.blade.php ENDPATH**/ ?>