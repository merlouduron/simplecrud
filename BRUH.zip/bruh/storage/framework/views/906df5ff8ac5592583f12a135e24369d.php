<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Naka login naka')); ?></div>

                <div class="card-body">
                    Welcome bai , nganu naa paman ka dri, continue na oi lamok

                    <a class="nav-link" href="<?php echo e(route('contact')); ?>">Continue nah</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\laravel prode\bruh\resources\views/thankyou.blade.php ENDPATH**/ ?>