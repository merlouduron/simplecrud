@extends('layout')

@section('content')
<div class="main">
<div class="body">
    <div class="taas">
        <h2 class="title">Edit</h2>
    </div>
    <div class="form">
        <form class="uiform" action="/update" method="post">
        @csrf
        <input type="hidden" name="contact_id" value="{{ $contact->id }}">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="{{ $contact->name }}" required>
        <label for="company">Company:</label>
        <input type="text" id="company" name="company" value="{{ $contact->company }}" required>
        <label for="phone">Phone:</label>
        <input type="number" id="phone" name="phone" value="{{ $contact->phone }}" required>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="{{ $contact->email }}" required>
        <input class="submit" type="submit" value="Submit">
    </form>
    </div>
</div>
</div>
@endsection
