@extends('layout')

@section('content')
<div class="main">
<div class="body">
    <div class="taas">
        <h2 class="title">Add</h2>
    </div>
    <div class="form">
        <form class="uiform" action="/submit" method="post">
        @csrf
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        <label for="company">Company:</label>
        <input type="text" id="company" name="company" required>
        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" required>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <input class="submit" type="submit" value="Submit">
    </form>
    </div>
</div>
</div>
@endsection
