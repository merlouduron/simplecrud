@extends('layout')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Naka login naka') }}</div>

                <div class="card-body">
                    Welcome bai , nganu naa paman ka dri, continue na oi lamok

                    <a class="nav-link" href="{{ route('contact') }}">Continue nah</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
