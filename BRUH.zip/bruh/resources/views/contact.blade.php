@extends('layout')

@section('content')
<div class="main">
<div class="body">
    <div class="taas">
        <h2 class="title">Contact</h2>
        <div class="pili">
            <a class="nav-add" href="{{ route('add') }}">Add kontak</a>
            <span class="list">kontak</span>
        </div>
    </div>

    <div class="drilist">
        <div class="search">
            <div class="searcharea">
                <span class="seearchicon"><i class="fas fa-search"></i></span>
                <input type="text" id="searchInput" class="formsearch" placeholder="search">
                <span class="clearicon"><i class="fas fa-times"></i></span>
            </div>

        </div>
        <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Company</th>
                <th>Phone</th>
                <th>Email</th>
                <th></th>
            </tr>
        </thead>
        <tbody id="contactList">
            @forelse ($getData as $contact)
                <tr class="contact-row">
                    <td>{{ $contact->name }}</td>
                    <td>{{ $contact->company }}</td>
                    <td>{{ $contact->phone }}</td>
                    <td>{{ $contact->email }}</td>
                    <td class="dd">
                        <a class="edit" href="{{ route('edit', ['id' => $contact->id]) }}">edayt</a>
                        <a class="delete-btn" data-contact-id="{{ $contact->id }}" href="#">delayt</a>
                    </td>
                    <div id="confirmDeleteModal" style="display: none;">
                        <div class="deletemodal">
                            <p>Are you sure you want to DELETE?</p>
                            <button id="cancelDeleteBtn">Ayaw</button>
                            <button id="confirmDeleteBtn">Ge lang, mao man jud ka.</button>
                        </div>
                    </div>
                </tr>
            @empty
                <tr>
                    <td colspan="4">Way data lamok</td>
                </tr>
            @endforelse



        </tbody>
    </table>
        <div id="paginationContainer">
            {{ $getData->links('pagination::bootstrap-4') }}
        </div>
    </div>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    var contactId;
    $(document).ready(function() {
        $('.delete-btn').on('click', function() {
            contactId = $(this).data('contact-id');

            $('#confirmDeleteModal').show();
        });

        $('#confirmDeleteBtn').on('click', function() {
                $('#confirmDeleteModal').hide();
                $.ajax({
                    url: '/delete/' + contactId,
                    method: 'GET',
                    success: function(response) {
                        console.log('delete request successful:', response);
                        location.reload()
                    },
                    error: function(error) {
                        console.error('delete request failed:', error);
                    }
                });
            });

            $('#cancelDeleteBtn').on('click', function() {
                $('#confirmDeleteModal').hide();
            });
    });
</script>

<script>
    var searchInput = document.getElementById('searchInput');
        var contactList = document.getElementById('contactList');
        var data = {!! json_encode($getFilter->toArray()) !!};

        searchInput.addEventListener('input', function() {
            performSearch();
        });

        function performSearch() {
            var searchQuery = searchInput.value.toLowerCase();
            $.ajax({
                url: '/search',
                method: 'GET',
                data: { query: searchQuery },
                success: function(response) {
                    updateContactList(response);
                },
                error: function(error) {
                    console.error('Error performing search:', error);
                }
            });
        }

        function updateContactList(contacts) {
            // Clear existing content in contactList
            contactList.innerHTML = '';

            if (contacts.length > 0) {
                contacts.forEach(function(contact) {
                    var tr = document.createElement('tr');
                    tr.className = 'contact-row';
                    tr.innerHTML = `
                        <td>${contact.name}</td>
                        <td>${contact.company}</td>
                        <td>${contact.phone}</td>
                        <td>${contact.email}</td>
                        <td class="dd">
                            <a class="edit" href="{{ url('edit') }}/${contact.id}">edayt</a>
                            <a class="delete-btn" data-contact-id="${contact.id}" href="#">delayt</a>
                        </td>
                    `;
                    contactList.appendChild(tr);
                });
            } else {
                var noResultsRow = document.createElement('tr');
                var noResultsCell = document.createElement('td');
                noResultsCell.colSpan = 5;
                noResultsCell.textContent = 'Way result.';
                noResultsRow.appendChild(noResultsCell);
                contactList.appendChild(noResultsRow);
            }
        }


        $(document).on('click', '.delete-btn', function() {
            contactId = $(this).data('contact-id');

            $('#confirmDeleteModal').show();
        });

</script>

@endsection

